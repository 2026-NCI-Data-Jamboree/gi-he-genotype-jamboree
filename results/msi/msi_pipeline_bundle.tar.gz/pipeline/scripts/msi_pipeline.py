"""MSI prediction from H&E across three NCI commons (IDC / GDC / PDC).

Stage 1  embed   : scripts/embed_stream2.py  - stream IDC DICOM WSIs, tile at 0.5 um/px
                   (224 px, HSV tissue mask, random cap 4,000 tiles, seed 0), embed with
                   Phikon (768-d) and UNI v1 (1024-d). GPU.
Stage 2  pool    : mean-pool tile features per slide -> one vector per slide. CPU.
Stage 3  model   : standardise -> logistic regression (class_weight='balanced'),
                   hospital-grouped 5-fold CV on the locked dev split.
Stage 4  evaluate: pooled out-of-fold AUROC, 2,000-draw bootstrap percentile CI,
                   confounder baselines (tissue source site, project, stage,
                   technical = objective power + series size).
Stage 5  external: fit on all dev, apply to the locked TCGA test split and to the
                   CPTAC-COAD slides (independent cohort, never used in training).
Stage 6  protein : PDC GraphQL quantDataMatrix for PDC000116 (Prospective COAD
                   Proteome, log2_ratio); join aliquot -> case -> slide; correlate the
                   image score with MMR protein abundance.
Stage 7  attribute: for a linear model on mean-pooled features the slide logit
                   decomposes EXACTLY into per-tile terms  w_eff . f_i , where
                   w_eff = coef / scale_ . Those terms are the attribution map.

Inputs : patient_split_locked.csv  (partition, cv_fold, label_msi, covariates)
         feature .h5 files         (datasets 'features', 'coords')
Outputs: msi_performance.csv, msi_slide_scores.csv, three_commons_table.csv,
         msi_protein_validation.csv, commons_gap_catalogue.csv, msi_attribution_maps.png
"""
