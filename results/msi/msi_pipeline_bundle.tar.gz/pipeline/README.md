# Reading the Genome Off the Slide — reproducible pipeline

Predicting microsatellite instability and driver mutations from routine H&E across
three NCI data commons: Imaging Data Commons (slides), Genomic Data Commons (labels),
Proteomic Data Commons (protein validation).

## Headline result (MSI, mean-pooled features + logistic regression)

| Evaluation | Phikon n / MSI-H | Phikon AUROC | UNI n / MSI-H | UNI AUROC |
|---|---|---|---|---|
| Dev, hospital-grouped CV | 807 / 131 | 0.765 [0.719-0.809] | 792 / 125 | 0.768 [0.717-0.816] |
| Locked TCGA test | 196 / 31 | 0.760 [0.667-0.838] | 191 / 29 | 0.826 [0.732-0.905] |
| CPTAC-COAD external | 140 / 35 | 0.701 [0.605-0.790] | 140 / 35 | 0.794 [0.702-0.878] |

The two encoders are scored on slightly different populations: 21 of the 1,004 eligible
slides have no UNI v1 feature file and 1 has no Phikon file, so each column reports its own
n and MSI-H count. The CPTAC-COAD external set is complete for both encoders.

Confounder baselines on dev: stage 0.557, project 0.556, tissue source site 0.487,
technical (objective power + series size) 0.425. None approaches the image model.

Benchmark: Kather et al. 2019 Nat Med reported 0.77 on TCGA-CRC-DX and 0.81 on TCGA-STAD.

## Cross-commons validation
94 CPTAC colon patients have slide + genomic MSI + protein. MSH2 and MSH6 are lower in
MSI-H (p=0.010, 0.031); the Phikon image score correlates negatively with MSH6
(Spearman rho=-0.25, p=0.014). MLH1 and PMS2 are NOT quantified in PDC000116, so the
MLH1-loss check cannot be run as originally specified.

## Known departures from the original methodology brief
- No Macenko stain normalisation; no Otsu thresholding (HSV mask instead);
  no blur/pen/fold filtering. The technical-confound baseline is reported instead.
- Tiles are 224 px, not 256 px. Random cap of 4,000 tiles per slide.
- Prov-GigaPath not used; Phikon (TCGA-pretrained) and UNI v1 (not TCGA-pretrained) used.
- Attention-MIL was trained for mutation labels; the MSI model here is a linear model on
  mean-pooled features, which matched attention-MIL on every mutation label tested.

## Scripts
- scripts/embed_stream2.py
- scripts/embed_stream3.py
- scripts/analyse_mut.py
- scripts/msi_pipeline.py — stage-by-stage description of the MSI run

## Data access
All inputs are open-access. No controlled-access or dbGaP tier is required.